1_original -> 2_cropped -> data

1_original : 원본 데이터
2_cropped : craft 통해 bounding box로 나뉜 데이터
data : deep-text-recognition의 폴더 구조를 가지는 lmdb 데이터